create database ssms;

connect to ssms;

create table login
(
userid int not null,
usertype int not null,
username varchar(15) not null,
password varchar(15) not null,

primary key(userid),
unique(username)
);

create table company
(
companyid int not null,
companyname varchar(30) not null,
email varchar(50) not null,
spacereq int not null,

primary key(companyid)
);

create table store
(
transid int not null,
companyid int not null,
dispatchcode varchar(15) not null,
dispatchname varchar(20),
spacereq int not null,
indate date not null,
outdate date,

primary key(transid),
constraint fk_companystore foreign key(companyid) references company(companyid) on delete cascade
);
