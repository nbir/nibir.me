insert into login values(1, 1, 'administrator', 'password');
