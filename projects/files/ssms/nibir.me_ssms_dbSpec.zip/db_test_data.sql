insert into login values( 2, 2, 'manager', 'mmmm');
insert into login values( 3, 3, 'store', 'ssss');


insert into login values( 4, 4, 'hcl', 'hhhh');
insert into company values( 4, 'HCL Technologies', 'test.ssms@gmail.com', 750);
insert into login values( 5, 4, 'jk', 'jjjj');
insert into company values( 5, 'JK Papers', 'test.ssms@gmail.com', 400);
insert into login values( 6, 4, 'hero', 'hhhh');
insert into company values( 6, 'Hero Honda Motors', 'test.ssms@gmail.com', 2500);
insert into login values( 7, 4, 'palmoliv', 'pppp');
insert into company values( 7, 'Palmoliv Ltd.', 'test.ssms@gmail.com', 700);
insert into login values( 8, 4, 'adidas', 'aaaa');
insert into company values( 8, 'Adidas Sports', 'test.ssms@gmail.com', 650);
insert into login values( 9, 4, 'tata', 'tttt');
insert into company values( 9, 'Tata Motors', 'test.ssms@gmail.com', 2300);
insert into login values( 10, 4, 'usha', 'uuuu');
insert into company values( 10, 'Usha Machines', 'test.ssms@gmail.com', 1200);


insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 1, 4, 'm17l', 'lcd monitor', 75, '2005-05-03');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 2, 4, 'la34me', 'me laptop', 50, '2005-05-03');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 3, 4, 'la37me', 'me laptop', 50, '2005-07-23');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 4, 4, 'k108', 'keyboard', 25, '2005-08-12');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 5, 5, 'd500', 'jk delux', 50, '2006-01-03');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 6, 5, 'c345', 'jk copier', 75, '2006-04-04');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 7, 6, 'h35w', 'head lamp', 35, '2006-04-15');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 8, 6, 'm56', 'mud guard', 25, '2006-06-18');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 9, 6, 'b-s45', 'splender bike', 650, '2006-12-17');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 10, 7, 'ct-45', 'toothpaste', 35, '2007-02-14');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 21, 7, 'ct-56', 'toothpaste', 50, '2008-04-20');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 22, 7, 's15', 'soap', 30, '2008-05-14');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 23, 7, 'c10', 'carton', 100, '2008-09-14');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 24, 8, 'b-d34', 'bag', 50, '2008-10-11');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 25, 8, 'b-7f8', 'bag', 75, '2008-11-01');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 26, 8, 't8ff9', 't-shirt', 50, '2008-11-01');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 27, 9, 'idsl', 'indica car', 1200, '2008-12-12');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 28, 9, 's789', 'spares', 300, '2008-12-13');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 29, 10, 'sw34', 'sewing machine', 250, '2008-12-23');
insert into store(transid, companyid, dispatchcode, dispatchname, spacereq, indate) values( 30, 10, 'n12', 'needle', 10, '2009-01-23');



insert into store values( 11, 4, 's-p467', 'computer', 150, '2007-02-14', '2008-08-13');
insert into store values( 12, 4, 'mp3', 'mouse', 35, '2007-04-02', '2007-06-14');
insert into store values( 13, 4, 's-i3', 'computer', 200, '2007-05-12', '2010-01-03');
insert into store values( 14, 5, 'c341', 'jk copier', 75, '2007-05-30', '2009-01-01');
insert into store values( 15, 5, 't5', 'toner', 50, '2007-07-07', '2007-07-30');
insert into store values( 16, 6, 'cdd333', 'cd delux bike', 450, '2007-08-09', '2010-02-03');
insert into store values( 17, 6, 'ex42', 'extreme bike', 250, '2007-10-05', '2008-04-15');
insert into store values( 18, 6, 't56', 'tyre', 150, '2008-01-17', '2008-08-14');
insert into store values( 19, 7, 'd90', 'soap', 75, '2008-03-04', '2009-01-01');
insert into store values( 20, 7, 't45', 'toothpaste', 50, '2008-03-04', '2008-05-15');
insert into store values( 31, 8, 's78', 'shoe', 100, '2009-01-25', '2009-03-15');
insert into store values( 32, 8, 's43', 'shoe', 50, '2009-01-27', '2009-12-12');
insert into store values( 33, 8, 't555', 't-shirt', 35, '2009-02-07', '2009-07-23');
insert into store values( 34, 8, 'c7', 'cap', 25, '2009-05-23', '2010-03-12');
insert into store values( 35, 8, 's890', 'sports acc', 100, '2009-06-12', '2010-05-12');
insert into store values( 36, 9, 'uf78', 'upholstery', 75, '2009-08-24', '2009-12-25');
insert into store values( 37, 9, 'ms568b', 'music system', 50, '2009-11-17', '2009-12-23');
insert into store values( 38, 9, 't67', 'tyre', 100, '2009-12-25', '2010-01-23');
insert into store values( 39, 10, 's45r', 'sewing machine', 250, '2010-01-03', '2010-03-14');
insert into store values( 40, 10, 'mx78', 'mixer grinder', 150, '2010-02-13', '2010-02-27');
