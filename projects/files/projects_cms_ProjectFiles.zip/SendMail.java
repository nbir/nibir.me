import java.io.*;

public class SendMail
{
        int employeeCode=0, repeatSelection=1;
        String senderUserName="", senderPassword="",senderName="", reciepient="", message="", sendingDate="";
        String name="", address="", phone="", post="", date="", userName="", password="", reciepientUserName="";

        InputStreamReader isr=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(isr);

        FileOutputStream fos;
        DataOutputStream dos;

        public void SendMail()
        {
                while(repeatSelection == 1)
                {
                        System.out.println("************************ SEND MAIL *************************");
                        System.out.println("");

                        GetInformation();
                        if(CheckPassword())
                        {
                                if(SearchReciepient())
                                {
                                        FileOpen();
                                        WriteMail();
                                        FileClose();
                                }
                                else
                                {
                                        System.out.println(" Reciepient Name does not exist ...");
                                }
                        }
                        else
                        {
                                System.out.println(" Invalid UserName or Password ...");
                        }

			System.out.println("");
			System.out.println("************************************************************");
			RepeatProcess();
                }
        }

        public void GetInformation()
        {
                try
                {
                        System.out.print(" Enter Your UserName : ");
                        senderUserName=br.readLine();
                        System.out.print(" Enter Your Password : ");
                        senderPassword=br.readLine();
                        System.out.println("");
                        System.out.print(" Enter Name of Employee to Send : ");
                        reciepient=br.readLine();
                        System.out.println("");
                        System.out.println(" Enter Message : ");
                        System.out.print("     ");
                        message=br.readLine();
                        System.out.println("");
                        System.out.print(" Enter Sending Date : ");
                        sendingDate=br.readLine();
                }
                catch(Exception e4)
                {}
        }

        public boolean CheckPassword()
        {
           boolean check=false, eof=false;
           try
           {
                FileInputStream fis=new FileInputStream("EmployeeDatabase.nnb");
                DataInputStream dis=new DataInputStream(fis);

                while(!eof)
                {
                        try
                        {
                                employeeCode=dis.readInt();
                                name=dis.readUTF();
                                address=dis.readUTF();
                                phone=dis.readUTF();
                                post=dis.readUTF();
                                date=dis.readUTF();
                                userName=dis.readUTF();
                                password=dis.readUTF();

                                if(senderUserName.equals(userName))
                                {
                                        if(senderPassword.equals(password))
                                        {
                                                check=true;
                                                senderName=name;
                                                eof=true;
                                        }
                                }
                        }
                        catch(EOFException e4)
                        {
                                System.out.println(" Invalid UserName !");
                                eof=true;
                                fis.close();
                                dis.close();
                        }
                }
           }
           catch(Exception e8)
           {}
           return check;
        }

        public boolean SearchReciepient()
        {
            boolean flag=false, eof=false;
            try
            {
                FileInputStream fis=new FileInputStream("EmployeeDatabase.nnb");
                DataInputStream dis=new DataInputStream(fis);

                while(!eof)
                {
                        try
                        {
                                employeeCode=dis.readInt();
                                name=dis.readUTF();
                                address=dis.readUTF();
                                phone=dis.readUTF();
                                post=dis.readUTF();
                                date=dis.readUTF();
                                userName=dis.readUTF();
                                password=dis.readUTF();

                                if(reciepient.equals(name))
                                {
                                        reciepientUserName=userName;
                                        flag=true;
                                        eof=true;
                                }
                        }
                        catch(EOFException e4)
                        {
                                System.out.println(" Invalid Employee Name !");
                                eof=true;
                                fis.close();
                                dis.close();
                        }
                }
            }
            catch(Exception e7)
            {}
            return flag;                
        }

        public void WriteMail()
        {
                try
                {
                        dos.writeUTF(senderName);
                        dos.writeUTF(sendingDate);
                        dos.writeUTF(message);
                }
                catch(Exception e5)
                {}
        }

        public void FileOpen()
        {
                try
                {                               
                        fos=new FileOutputStream(reciepientUserName+".nnb", true);
                        dos=new DataOutputStream(fos);
                }
                catch(FileNotFoundException e1)
                {}
        }

        public void FileClose()
        {
                try
                {
                        dos.close();
                        fos.close();
                }
                catch(Exception e2)
                {}
        }

        public void RepeatProcess()
        {
                try
                {
                        System.out.println("");
                        System.out.print(" Send More Mail - 1 ***** Return to Main Menu - 0 : ... ");
                        repeatSelection=Integer.parseInt(br.readLine());
                }
                catch(Exception e3)
                {}
        }

}
