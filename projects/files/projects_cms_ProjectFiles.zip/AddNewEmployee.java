import java.io.*;

public class AddNewEmployee
{
        int employeeCode=1000, repeatSelection=1, checkEmployeeCode=0;
        String name="", address="", phone="", post="", date="", userName="", password="";
        String checkName="", checkAddress="", checkPhone="", checkPost="", checkDate="", checkUserName="", checkPassword="";
        boolean userNameExist=true;

        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        FileOutputStream fos, fos1;
        DataOutputStream dos, dos1;

        public void AddNewEmployee()
        {
                FileOpen();

                while(repeatSelection == 1)
                {
                        System.out.println("");
                        System.out.println("********************* ADD NEW USER *************************");

                        GetInformation();
                        GetEmployeeCode();

                        System.out.println("");
                        System.out.println(" Your Employee Code is : " + employeeCode);
                        System.out.println("************************************************************");

                        SendInformation();
                        RepeatProcess();

                        userNameExist=true;
                }

                FileClose();
        }

        public void GetInformation()
        {
                try
                {
                        System.out.println(" Please Enter Your Personal Information : ...");
                        System.out.println("");
                        System.out.print(" Name : ");
                        name=br.readLine();
                        System.out.print(" Address : ");
                        address=br.readLine();
                        System.out.print(" Phone No. : ");
                        phone=br.readLine();
                        System.out.print(" Post : ");
                        post=br.readLine();
                        System.out.print(" Date of Joining : ");
                        date=br.readLine();
                        System.out.println("");
                                               
                        while(userNameExist)
                        {
                                System.out.print("User Name : ");
                                userName=br.readLine();

                                CheckUserNameExistance();
                        }

                        System.out.print("Password : ");
                        password=br.readLine();
                }
                catch(Exception e7)
                {}
        }

        public void SendInformation()
        {
                try
                {
                        dos.writeInt(employeeCode++);
                        dos.writeUTF(name);
                        dos.writeUTF(address);
                        dos.writeUTF(phone);
                        dos.writeUTF(post);
                        dos.writeUTF(date);
                        dos.writeUTF(userName);
                        dos.writeUTF(password);
                }
                catch(Exception e5)
                {}
        }

        public void CheckUserNameExistance()
        {
           boolean eof=false;
           try
           {
                FileInputStream fis=new FileInputStream("EmployeeDatabase.nnb");
                DataInputStream dis=new DataInputStream(fis);

                while(!eof)
                {
                        try
                        {
                                checkEmployeeCode=dis.readInt();
                                checkName=dis.readUTF();
                                checkAddress=dis.readUTF();
                                checkPhone=dis.readUTF();
                                checkPost=dis.readUTF();
                                checkDate=dis.readUTF();
                                checkUserName=dis.readUTF();
                                checkPassword=dis.readUTF();

                                if(checkUserName.equals(userName))
                                {

                                        System.out.println("");
                                        System.out.println(" The UserName You have Entered Already exists !");
                                        eof=true;
                                }          
                        }
                        catch(EOFException e4)
                        {
                                userNameExist=false;
                                eof=true;
                                fis.close();
                                dis.close();
                        }
                }
           }
           catch(Exception e8)
           {}
        }

        public void GetEmployeeCode()
        {
                boolean eof=false;                
                try
                {
                        FileInputStream fin=new FileInputStream("EmployeeCode.nnb");
                        DataInputStream din=new DataInputStream(fin);
                                
                        while(!eof)
                        {
                                try
                                {
                                        employeeCode=din.readInt();                                                
                                }
                                catch(EOFException e3)
                                {
                                        eof=true;
                                        din.close();
                                        fin.close();                                       
                                }
                        }             
                        dos1.writeInt(employeeCode+1);
                }
                catch(Exception e4)
                {}
        }

        public void CreateUserDatabase()
        {
                try
                {        
			FileOutputStream fos2=new FileOutputStream(userName+".nnb");
                        DataOutputStream dos2=new DataOutputStream(fos2);
                        fos2.close();
                        dos2.close();
                }
                catch(Exception e7)
                {}                
        }
        
        public void FileOpen()
        {
                File f1 = new File("EmployeeDatabase.nnb");
                File f2 = new File("EmployeeCode.nnb");
                try
                {
                        if(f1.exists())
                        {
                                fos=new FileOutputStream("EmployeeDatabase.nnb", true);
                                dos=new DataOutputStream(fos);
                        }
                        else
                        {
                                fos=new FileOutputStream("EmployeeDatabase.nnb");
                                dos=new DataOutputStream(fos);
                        }
                                                
                        if(f2.exists())
                        {
                                fos1=new FileOutputStream("EmployeeCode.nnb", true);
                                dos1=new DataOutputStream(fos1);
                        }
                        else
                        {
                                fos1=new FileOutputStream("EmployeeCode.nnb");
                                dos1=new DataOutputStream(fos1); 
                        }       
                }
                catch(FileNotFoundException e1)
                {}
        }

        public void FileClose()
        {
                try
                {
                        dos.close();
                        fos.close();

                        fos1.close();
                        dos1.close();
                }
                catch(Exception e2)
                {}
        }

        public void RepeatProcess()
        {
                try
                {
                        System.out.println("");
                        System.out.print(" Add New Employee - 1 ***** Return to Main Menu - 0 : ... ");
                        repeatSelection=Integer.parseInt(br.readLine());
                }
                catch(Exception e6)
                {}
        }
}
