import java.io.*;

public class ViewProfile
{
        int employeeCode=0, searchEmployeeCode=0, repeatSelection=1, option =0;
        String name="", address="", phone="", post="", date="", userName="", password="";
        String employeeUserName="", employeeName="";

        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        FileInputStream fis;
        DataInputStream dis;

        public void ViewProfile()
        {
                while(repeatSelection == 1)
                {
                        System.out.println("*********************** VIEW PROFILE ***********************");
                        System.out.println("");
                        GetOption();
                        GetInformation();
                        FileOpen();
                                                                        
                        System.out.println("");
                        switch(option)
                        {
                                case 1:                                         
                                        SearchByName();
                                        break;
                                case 2:                                         
                                        SearchByUserName();
                                        break;
                                case 3:                                         
                                        SearchByEmployeeCode();
                                        break;
                                default:
                                        System.out.println("");
                                        System.out.println(" Invalid Selection .. ");
                                        break;
                        }                        

                        FileClose();

                        System.out.println("************************************************************");
                        RepeatProcess();
                }
        }

        public void GetOption()
        {
                try
                {
                        System.out.println(" By which Option do you wish to search ..");
                        System.out.println("     1................EMPLOYEE NAME");
                        System.out.println("     2................USER NAME");
                        System.out.println("     3................EMPLOYEE CODE");
                        System.out.print("     Your Option ... ");
                        option = Integer.parseInt(br.readLine());
                }
                catch(Exception e5)
                {}
        }

        public void GetInformation()
        {
                try
                {
                        switch(option)
                        {
                        case 1:
                                System.out.println("");
                                System.out.print(" Enter Employee Name : ");
                                employeeName=br.readLine();
                                break;
                        case 2:
                                System.out.println("");
                                System.out.print(" Enter UserName : ");
                                employeeUserName=br.readLine();
                                break;
                        case 3:
                                System.out.println("");
                                System.out.print(" Enter Employee Code : ");
                                searchEmployeeCode=Integer.parseInt(br.readLine());
                                break;
                        }
                }
                catch(Exception e4)
                {}
        }

        public void SearchByName()
        {
                boolean eof=false;
                try
                {
                        while(!eof)
                        {
                                try
                                {
					employeeCode=dis.readInt();
                              		name=dis.readUTF();
                                        address=dis.readUTF();
                                        phone=dis.readUTF();
                                        post=dis.readUTF();
                                        date=dis.readUTF();
                                        userName=dis.readUTF();
                                        password=dis.readUTF();

                                        if(employeeName.equals(name))
                                        {
                                                System.out.println(" Employee Code : " + employeeCode);
                                                System.out.println(" Name : " + name);
                                                System.out.println(" Address : " + address);
                                                System.out.println(" Phone No. : "+ phone);
                                                System.out.println(" Post : " + post);
                                                System.out.println(" Date of Joining : " + date);
                                                System.out.println(" UserName : " + userName);

                                                break;
                                        }
                                 }
                                catch(EOFException e7)
                                {
                                        System.out.println("");
                                        System.out.println(" Invalid  Employee Name !");
                                        eof=true;
                                }
                        }
                }
                catch(Exception e6)
                {}
                
        }

        public void SearchByUserName()
        {
                boolean eof=false;
                try
                {
                        while(!eof)
                        {
                                try
                                {
					employeeCode=dis.readInt();
                              		name=dis.readUTF();
                                        address=dis.readUTF();
                                        phone=dis.readUTF();
                                        post=dis.readUTF();
                                        date=dis.readUTF();
                                        userName=dis.readUTF();
                                        password=dis.readUTF();

                                        if(employeeUserName.equals(userName))
                                        {
                                                System.out.println(" Employee Code : " + employeeCode);
                                                System.out.println(" Name : " + name);
                                                System.out.println(" Address : " + address);
                                                System.out.println(" Phone No. : "+ phone);
                                                System.out.println(" Post : " + post);
                                                System.out.println(" Date of Joining : " + date);
                                                System.out.println(" UserName : " + userName);

                                                break;
                                        }
                                 }
                                catch(EOFException e8)
                                {
                                        System.out.println("");
                                        System.out.println(" Invalid UserName !");
                                        eof=true;
                                }
                        }
                }
                catch(Exception e9)
                {}

        }

        public void SearchByEmployeeCode()
        {
                boolean eof=false;
                try
                {
                        while(!eof)
                        {
                                try
                                {
					employeeCode=dis.readInt();
                              		name=dis.readUTF();
                                        address=dis.readUTF();
                                        phone=dis.readUTF();
                                        post=dis.readUTF();
                                        date=dis.readUTF();
                                        userName=dis.readUTF();
                                        password=dis.readUTF();

                                        if(searchEmployeeCode == employeeCode)
                                        {
                                                System.out.println(" Employee Code : " + employeeCode);
                                                System.out.println(" Name : " + name);
                                                System.out.println(" Address : " + address);
                                                System.out.println(" Phone No. : "+ phone);
                                                System.out.println(" Post : " + post);
                                                System.out.println(" Date of Joining : " + date);
                                                System.out.println(" UserName : " + userName);

                                                break;
                                        }             
                                 }
                                catch(EOFException e10)
                                {
                                        System.out.println("");
                                        System.out.println(" Invalid Employee Code !");
                                        eof=true;
                                }
                        }
                }
                catch(Exception e11)
                {}
                
        }
        
	public void FileOpen()
        {                 
                try
                {                               
                        fis=new FileInputStream("EmployeeDatabase.nnb");
                        dis=new DataInputStream(fis);
                }
                catch(FileNotFoundException e1)
                {}
        }

        public void FileClose()
        {
                try
                {
                        dis.close();
                        fis.close();
                }
                catch(Exception e2)
                {}
        }

        public void RepeatProcess()
        {
                try
                {
                        System.out.println("");
                        System.out.print(" Search More Profiles - 1 ***** Return to Main Menu - 0 : ... ");
                        repeatSelection=Integer.parseInt(br.readLine());
                }
                catch(Exception e3)
                {}
        }

}
