import java.io.*;

public class CheckMail
{
        int employeeCode=0, repeatSelection=1;
        String name="", address="", phone="", post="", date="", userName="", password="";
        String reciepientUserName="", reciepientPassword="";
        String senderName="", sendingDate="", message="";
        
        InputStreamReader isr=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(isr);

        FileInputStream fis, fis1;
        DataInputStream dis, dis1;

        FileOutputStream fos;
        DataOutputStream dos;
        
        public void CheckMail()
        {
                while(repeatSelection == 1)
                {
                        System.out.println("************************ CHECK MAIL ************************");
                        System.out.println("");

                        GetInformation();                        
                        if(CheckPassword())
                        {
                                FileOpen();                                                    
                                GetAndDisplayMail();
                                ClearInbox();
                                FileClose();
                        }
                        else
                        {
                                System.out.println(" Invalid UserName or Password ...");
                        }

                        System.out.println("************************************************************");
			RepeatProcess();
                }
        }

        public void GetInformation()
        {
                try
                {
                        System.out.print(" Enter Your UserName : ");
                        reciepientUserName=br.readLine();
                        System.out.print(" Enter Your Password : ");
                        reciepientPassword=br.readLine();
                        System.out.println("");
                }
                catch(Exception e4)
                {}
        }

        public boolean CheckPassword()
        {
           boolean check=false, eof=false;
           try
           {
                FileInputStream fis2=new FileInputStream("EmployeeDatabase.nnb");
                DataInputStream dis2=new DataInputStream(fis2);

                while(!eof)
                {
                        try
                        {
                                employeeCode=dis2.readInt();
                                name=dis2.readUTF();
                                address=dis2.readUTF();
                                phone=dis2.readUTF();
                                post=dis2.readUTF();
                                date=dis2.readUTF();
                                userName=dis2.readUTF();
                                password=dis2.readUTF();

                                if(reciepientUserName.equals(userName))
                                {
                                        if(reciepientPassword.equals(password))
                                        {
                                                check=true;
                                                eof=true;                                        
                                        }
                                }       
                        }
                        catch(EOFException e4)
                        {
                                System.out.println(" Invalid UserName !");
                                eof=true;
                                fis2.close();
                                dis2.close();
                        }
                }

           }
           catch(Exception e8)
           {}

           return check;
        }


        public void GetAndDisplayMail()
        {                       
                boolean eof=false;
                try
                {
                        while(!eof)
                        {
                                try
                                {
                                        senderName=dis.readUTF();
                                        sendingDate=dis.readUTF();
                                        message=dis.readUTF();
                                }
                                catch(EOFException e67)
                                {
                                        eof=true;
                                }

                                if(senderName.equals(""))
                                {
                                        System.out.println(" Your Inbox is Empty ..");
                                }
                                else
                                {
                                        System.out.println("");
                                        System.out.println("Sender : " + senderName);
                                        System.out.println("Sent On : " + sendingDate);
                                        System.out.println("");
                                        System.out.println("Message :-");
                                        System.out.println("    " + message);
                                        System.out.println("");
                                        System.out.println("------------------------------------------------------------");

                                        senderName="";
                                        sendingDate="";
                                        message="";
                                }
                        }                        
                }
                catch(Exception e5)
                {}
        }

        public void ClearInbox()
        {
                try
                {
                        fos=new FileOutputStream(reciepientUserName+".nnb");
                        dos=new DataOutputStream(fos);

                        fos.close();
                        dos.close();                        
                }
                catch(Exception e)
                {}
        }

        public void FileOpen()
        {                 
                try
                {                               
                        File f4 = new File(reciepientUserName+".nnb");

                        if(f4.exists())
                        {
                                fis=new FileInputStream(reciepientUserName+".nnb");
                                dis=new DataInputStream(fis);
                        }
                        else
                        {
                                System.out.println(" Your Inbox is Empty ..");
                        }
                }
                catch(FileNotFoundException e1)
                {}
        }

        public void FileClose()
        {
                try
                {
                        dis.close();
                        fis.close();
                }
                catch(Exception e2)
                {}
        }

        public void RepeatProcess()
        {
                try
                {
                        System.out.println("");
                        System.out.print(" Check More Mail - 1 ***** Return to Main Menu - 0 : ... ");
                        repeatSelection=Integer.parseInt(br.readLine());
                }
                catch(Exception e3)
                {}
        }
}
