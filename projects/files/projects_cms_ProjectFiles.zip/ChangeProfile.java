import java.io.*;

public class ChangeProfile
{
        int employeeCode=0, repeatSelection=1, checkEmployeeCode=0;
        String name="", address="", phone="", post="", date="", userName="", password="";
        String changerUserName="", changerPassword="";
        String checkName="", checkAddress="", checkPhone="", checkPost="", checkDate="", checkUserName="", checkPassword="";
        boolean userNameExist=true;
                
        InputStreamReader isr=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(isr);

        FileInputStream fis;
        DataInputStream dis;

        public void ChangeProfile()
        {
                while(repeatSelection == 1)
                {
                        System.out.println("*********************** CHANGE PROFILE *********************");
                        System.out.println("");

                        GetPassword();
                        if(CheckPassword())
                        {
                                FileOpen();

                                System.out.println(" Your Old Profile is :-");
                                System.out.println("");
                                DisplayProfile();

                                System.out.println("");
                                System.out.println(" Enter Your New Profile :-");
                                GetNewProfile();

                                UpdateDatabase();
                                FileClose();

                                System.out.println(" Your Profile has been Updated.");                                
                        }
                        else
                        {
                                System.out.println(" Invalid UserName or Password ...");
                        }
			System.out.println("************************************************************");
                        userNameExist=true;
                        RepeatProcess();
                }
        }

        public void GetPassword()
        {
                try
                {
                        System.out.print(" Enter Your UserName : ");
                        changerUserName=br.readLine();
                        System.out.print(" Enter Your Password : ");
                        changerPassword=br.readLine();
                        System.out.println("");
                }
                catch(Exception e4)
                {}
        }

        public boolean CheckPassword()
        {
           boolean check=false, eof=false;
           try
           {
                FileInputStream fis=new FileInputStream("EmployeeDatabase.nnb");
                DataInputStream dis=new DataInputStream(fis);

                while(!eof)
                {
                        try
                        {
                                employeeCode=dis.readInt();
                                name=dis.readUTF();
                                address=dis.readUTF();
                                phone=dis.readUTF();
                                post=dis.readUTF();
                                date=dis.readUTF();
                                userName=dis.readUTF();
                                password=dis.readUTF();

                                if(changerUserName.equals(userName))
                                {
                                        if(changerPassword.equals(password))
                                        {
                                                check=true;
                                                break;
                                        }
                                }
                        }
                        catch(EOFException e4)
                        {
                                eof=true;
                        }
                }
           }
           catch(Exception e8)
           {}
           return check;
        }

        public void DisplayProfile()
        {
                System.out.println(" Employee Code : " + employeeCode);
                System.out.println(" Name : " + name);
                System.out.println(" Address : " + address);
                System.out.println(" Phone No. : "+ phone);
                System.out.println(" Post : " + post);
                System.out.println(" Date of Joining : " + date);
                System.out.println(" UserName : " + userName);
        }

        public void GetNewProfile()
        {
                try
                {                               
                        System.out.println("");
                        System.out.print(" Name : ");
                        name=br.readLine();
                        System.out.print(" Address : ");
                        address=br.readLine();
                        System.out.print(" Phone No. : ");
                        phone=br.readLine();
                        System.out.print(" Post : ");
                        post=br.readLine();
                        System.out.print(" Date of Joining : ");
                        date=br.readLine();
                        System.out.println("");

                        while(userNameExist)
                        {
                                System.out.print("User Name : ");
                                userName=br.readLine();

                                CheckUserNameExistance();                                                                
                        }
                        System.out.print("Password : ");
                        password=br.readLine();

                }
                catch(Exception e7)
                {}
        }

        public void CheckUserNameExistance()
        {
           boolean eof=false;
           try
           {
                FileInputStream fis=new FileInputStream("EmployeeDatabase.nnb");
                DataInputStream dis=new DataInputStream(fis);

                while(!eof)
                {
                        try
                        {
                                checkEmployeeCode=dis.readInt();
                                checkName=dis.readUTF();
                                checkAddress=dis.readUTF();
                                checkPhone=dis.readUTF();
                                checkPost=dis.readUTF();
                                checkDate=dis.readUTF();
                                checkUserName=dis.readUTF();
                                checkPassword=dis.readUTF();

                                if(userName.equals(changerUserName))
                                {
                                        userNameExist=false;
                                }
                                else if(checkUserName.equals(userName))
                                {               
                                        System.out.println("");
                                        System.out.println(" The UserName You have Entered Already exists !");
                                        eof=true;
                                }          
                        }
                        catch(EOFException e4)
                        {
                                userNameExist=false;
                                eof=true;
                                fis.close();
                                dis.close();
                        }
                  }
           }
           catch(Exception e8)
           {}
        }
        
        public void UpdateDatabase()
        {
                boolean eof=false;
                int i=0, counter=0, position=0;

                int employeeCodeArr[] = new int[100];
                String nameArr[]=new String[100];
                String addressArr[]=new String[100];
                String phoneArr[]=new String[100];
                String postArr[]=new String[100];
                String dateArr[]=new String[100];
                String userNameArr[]=new String[100];
                String passwordArr[]=new String[100];

                try
                {
                        while(!eof)
                        {
                                try
                                {
                                        employeeCodeArr[counter] = dis.readInt();
                                        nameArr[counter] = dis.readUTF();
                                        addressArr[counter] = dis.readUTF();
                                        phoneArr[counter] = dis.readUTF();
                                        postArr[counter] = dis.readUTF();
                                        dateArr[counter] = dis.readUTF();
                                        userNameArr[counter] = dis.readUTF();
                                        passwordArr[counter] = dis.readUTF();

                                        if(userNameArr[counter].equals(changerUserName))
                                        {
                                                position = counter;
                                        }
                                }
                                catch(EOFException e14)
                                {
                                        eof=true;
                                }
                                counter++;

                        }
                }
                catch(Exception e15)
                {}

                employeeCodeArr[position] = employeeCode;
                nameArr[position] = name;
                addressArr[position] = address;
                phoneArr[position] = phone;
                postArr[position] = post;
                dateArr[position] = date;
                userNameArr[position] = userName;
                passwordArr[position] = password;

                try
                {
                        FileOutputStream fos=new FileOutputStream("EmployeeDatabase.nnb");
                        DataOutputStream dos=new DataOutputStream(fos);

                        for(i=0;i<counter;i++)
                        {
                                dos.writeInt(employeeCodeArr[i]);
                                dos.writeUTF(nameArr[i]);
                                dos.writeUTF(addressArr[i]);
                                dos.writeUTF(phoneArr[i]);
                                dos.writeUTF(postArr[i]);
                                dos.writeUTF(dateArr[i]);
                                dos.writeUTF(userNameArr[i]);
                                dos.writeUTF(passwordArr[i]);
                        }
                }
                catch(Exception e16)
                {}
        }

        public void FileOpen()
        {                 
                try
                {                               
                        fis=new FileInputStream("EmployeeDatabase.nnb");
                        dis=new DataInputStream(fis);
                }
                catch(FileNotFoundException e1)
                {}
        }

        public void FileClose()
        {
                try
                {
                        dis.close();
                        fis.close();
                }
                catch(Exception e2)
                {}
        }

        public void RepeatProcess()
        {
                try
                {
                        System.out.println("");
                        System.out.print(" Change More Profile - 1 ***** Return to Main Menu - 0 : ... ");
                        repeatSelection=Integer.parseInt(br.readLine());
                }
                catch(Exception e3)
                {}
        }
}
