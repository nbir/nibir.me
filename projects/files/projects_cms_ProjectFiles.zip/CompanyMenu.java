import java.io.*;

public class CompanyMenu
{
        public static void main(String ar[])
        {
                int selection=1;

                InputStreamReader isr = new InputStreamReader(System.in);
                BufferedReader br = new BufferedReader(isr);

                System.out.println("************************************************************");
                System.out.println("*----------------------------------------------------------*");
                System.out.println("*|                A COMPANY SOFTWARE MODEL                |*");
                System.out.println("*|                Project for ICSE 2005-06                |*");
                System.out.println("*|                  By NIBIR NAYAN BORA                   |*");
                System.out.println("*----------------------------------------------------------*");


                try
                {
                        while(selection != 0)
                        {
                                System.out.println("************************************************************");
                                System.out.println("          SL. NO.                             OPTION");
                                System.out.println("------------------------------------------------------------");
                                System.out.println("           1. ....................... ADD NEW EMPLOYEE");
                                System.out.println("           2. ....................... VIEW PROFILE");
                                System.out.println("           3. ....................... CHANGE PROFILE");
                                System.out.println("           4. ....................... SEND MAIL");
                                System.out.println("           5. ....................... CHECK MAIL");
                                System.out.println("");
                                System.out.println("           0. ....................... EXIT");
                                System.out.println("************************************************************");
                                System.out.print("           Enter Your Option [0 - 5] ... ");
                                selection = Integer.parseInt(br.readLine());
                                System.out.println("************************************************************");

                                switch(selection)
                                {
                                        case 1:
                                                AddNewEmployee ane = new AddNewEmployee();
                                                ane.AddNewEmployee();
                                                break;
                                        case 2:
                                                ViewProfile vf = new ViewProfile();
                                                vf.ViewProfile();
                                                break;
                                        case 3:
                                                ChangeProfile cf = new ChangeProfile();
                                                cf.ChangeProfile();
                                                break;
                                        case 4:
                                                SendMail sm = new SendMail();
                                                sm.SendMail();
                                                break;
                                        case 5:
                                                CheckMail cm = new CheckMail();
                                                cm.CheckMail();
                                                break;
                                        default:
                                                System.out.println("");
                                                System.out.println("************************************************************");
                                                System.out.println("*----------------------- THANK YOU ------------------------*");
                                                System.out.println("************************************************************");
                                                
                                }
                        }
                }
                catch(Exception e)
                {}
        }
}
